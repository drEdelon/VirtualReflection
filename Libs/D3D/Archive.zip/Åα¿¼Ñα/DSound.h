#pragma once
#include <dsound.h>
#pragma comment(lib,"dsound.lib")
#pragma comment(lib,"winmm.lib")
//=================================================================================================================
#define MAX_SOUND		256

#define SOUND_NULL		0
#define SOUND_LOADED	1
#define SOUND_PLAYING	2
#define SOUND_STOPPED	3

#define SOUND_PLAY_ONCE 0
#define SOUND_PLAY_LOOP DSBPLAY_LOOPING

#define LEFT_SPEAKER	-10000
#define RIGHT_SPEAKER	 10000
#define CENTER			0

#define VOLUME_TO_DB(volume)((DWORD)(-30*(100-volume)))
//=================================================================================================================
class DSound
{
	typedef struct SOUND_TYP
	{
		LPDIRECTSOUNDBUFFER dsBuffer;
		int state;
		int rate;
		int size;
		int number;
	} SOUND,*SOUND_PTR;

	LPDIRECTSOUND8			lp_DS;
	DSBUFFERDESC			DS_bd;
	LPDIRECTSOUNDBUFFER8	lp_primare;
	WAVEFORMATEX			pcwmf;
	SOUND					sound[MAX_SOUND];
	HMMIO					hwave;
	MMCKINFO				parent;
	MMCKINFO				child;
	WAVEFORMATEX			wfmtx;

public:
	DSound()
	{
		lp_DS = NULL;
		lp_primare = NULL;
	}
	~DSound()
	{
		DS_StopAllSound();
		DS_DeleteAllSound();
	}
	bool DS_Init(HWND hwnd);
	void DS_Shutdown(void);
	int DS_LoadWave(char *fileName,int control_Flag);
	bool DS_PlaySound(int id,int flags);
	bool DS_SetVolume(int id,int Volume);
	bool DS_SetFrequence(int id,int freq);
	bool DS_SetPan(int id,int pan);
	bool DS_StopSound(int id);
	bool DS_StopAllSound(void);
	bool DS_DeleteSound(int id);
	bool DS_DeleteAllSound(void);
};
//=================================================================================================================