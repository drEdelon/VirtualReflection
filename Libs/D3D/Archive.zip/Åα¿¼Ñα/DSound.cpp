#include "DSound.h"
//=================================================================================================================
bool DSound::DS_Init(HWND hwnd)
{
	HRESULT hr;

	memset(sound,0,sizeof(SOUND)*MAX_SOUND);
	hr = DirectSoundCreate8(NULL,&lp_DS,NULL);
	if(FAILED(hr))
	{
		DS_Shutdown();
		return false;
	}

	hr = lp_DS->SetCooperativeLevel(hwnd,DSSCL_NORMAL);
	if(FAILED(hr))
	{
		DS_Shutdown();
		return false;
	}

	for(int i=0; i<MAX_SOUND; i++)
	{
		if(sound[i].dsBuffer)
		{
			sound[i].dsBuffer->Stop();
			sound[i].dsBuffer->Release();
		}
		memset(&sound[i],0,sizeof(SOUND));
		sound[i].state = SOUND_NULL;
		sound[i].number = i;
	}
  return true;
}
//=================================================================================================================
void DSound::DS_Shutdown(void)
{
	for(int i=0;i<MAX_SOUND;i++)
	{
		sound[i].dsBuffer->Release();
		sound[i].number = 0;
		sound[i].rate = 0;
		sound[i].size = 0;
		sound[i].state = SOUND_NULL;
	}

	if(lp_DS)
	{
		if(FAILED(lp_DS->Release())){}
	}
}
//=================================================================================================================
int DSound::DS_LoadWave(char *filename,int control_flag)
{
	int soundID = -1;

	UCHAR* snd_BUF,
		 * audio_ptr1=NULL,
		 * audio_ptr2=NULL;

	DWORD audio_len1=0,
		  audio_len2=0;

	for(int i=0; i<MAX_SOUND; i++)
	{
		if(sound[i].state==SOUND_NULL)
		{
			soundID = i;
			break;
		}
	}

	if(soundID==-1)return -1;

	parent.ckid			=(FOURCC)0;
	parent.cksize		=0;
	parent.fccType		=(FOURCC)0;
	parent.dwDataOffset	=0;
	parent.dwFlags		=0;

	child=parent;

	if((hwave=mmioOpenA(filename,NULL,MMIO_READ | MMIO_ALLOCBUF))==NULL)return 0;

	parent.fccType = mmioFOURCC('W','A','V','E');
	if(mmioDescend(hwave,&parent,NULL,MMIO_FINDRIFF))
	{
		mmioClose(hwave,0);
	  return -1;
	}

	child.ckid = mmioFOURCC('f','m','t',' ');
	if(mmioDescend(hwave,&child,&parent,0))
	{
		mmioClose(hwave,0);
	  return -1;
	}

	if(mmioRead(hwave,(char*)&wfmtx,sizeof(wfmtx))!=sizeof(wfmtx))
	{
		mmioClose(hwave,0);
	  return -1;
	}

	if(wfmtx.wFormatTag!=WAVE_FORMAT_PCM)
	{
		mmioClose(hwave,0);
	  return -1;
	}

	if(mmioAscend(hwave,&child,0))
	{
		mmioClose(hwave,0);
	  return -1;
	}

	child.ckid = mmioFOURCC('d','a','t','a');
	if(mmioDescend(hwave,&child,&parent,MMIO_FINDCHUNK))
	{
		mmioClose(hwave,0);
	  return -1;
	}

	snd_BUF = (UCHAR*)malloc(child.cksize);

	mmioRead(hwave,(char*)snd_BUF,child.cksize);
	mmioClose(hwave,0);

	sound[soundID].rate = wfmtx.nSamplesPerSec;
	sound[soundID].size = child.cksize;
	sound[soundID].state = SOUND_LOADED;
	
	memset(&pcwmf,0,sizeof(WAVEFORMATEX));
	pcwmf.wFormatTag		= WAVE_FORMAT_PCM;	//Pulse code modulation
	pcwmf.nChannels			= 1;				//Mono sound (not stereo :( )
	pcwmf.nSamplesPerSec	= 44100;
	pcwmf.nBlockAlign		= 1;
	pcwmf.nAvgBytesPerSec	= pcwmf.nSamplesPerSec * pcwmf.nBlockAlign;
	pcwmf.wBitsPerSample	= 8;
	pcwmf.cbSize			= 0;

	memset(&DS_bd,0,sizeof(DSBUFFERDESC));
	DS_bd.dwSize		= sizeof(DSBUFFERDESC);
	DS_bd.dwFlags		= control_flag | DSBCAPS_STATIC | DSBCAPS_CTRLVOLUME |
										 DSBCAPS_CTRLPAN | DSBCAPS_CTRLPOSITIONNOTIFY |
										 DSBCAPS_CTRLFREQUENCY | DSBCAPS_LOCSOFTWARE;
	DS_bd.dwBufferBytes	= child.cksize;
	DS_bd.lpwfxFormat	= &pcwmf;

	if(FAILED(lp_DS->CreateSoundBuffer(&DS_bd,&sound[soundID].dsBuffer,NULL)))
	{
		free(snd_BUF);
	  return -1;
	}

	if(FAILED(sound[soundID].dsBuffer->Lock(0,child.cksize,
											(void**)&audio_ptr1,
											&audio_len1,
											(void**)&audio_ptr2,
											&audio_len2,
											DSBLOCK_FROMWRITECURSOR)))
	{
		MessageBoxA(0,"LPDIRECTSOUND Error: Could not copy data into buffer",0,0);
	  return 0;
	}

	memcpy(audio_ptr1,snd_BUF,audio_len1);
	memcpy(audio_ptr2,(snd_BUF+audio_len2),audio_len2);

	if(FAILED(sound[soundID].dsBuffer->Unlock(audio_ptr1,
											  audio_len1,
											  audio_ptr2,
											  audio_len2)))
	{
		MessageBoxA(0,"LPDIRECTSOUND Error: Could not unlock the buffer",0,0);
		return 0;
	}

	free(snd_BUF);
  return soundID;
}
//=================================================================================================================
bool DSound::DS_PlaySound(int id,int flags)
{
	if(sound[id].dsBuffer)
	{		
		if(FAILED(sound[id].dsBuffer->SetCurrentPosition(0)))return false;		
		if(FAILED(sound[id].dsBuffer->Play(0,0,flags)))return false;
	}

  return true;
}
//=================================================================================================================
bool DSound::DS_SetVolume(int id,int Volume)
{	
	if(sound[id].dsBuffer->SetVolume(VOLUME_TO_DB(Volume))!=DS_OK)return false;
  return true;
}
//=================================================================================================================
bool DSound::DS_SetFrequence(int id,int freq)
{
	if(sound[id].dsBuffer->SetFrequency(freq)!=DS_OK)return false;
  return true;
}
//=================================================================================================================
bool DSound::DS_SetPan(int id, int pan)
{
	if(sound[id].dsBuffer->SetPan(pan)!=DS_OK)return false;
  return true;
}
//=================================================================================================================
bool DSound::DS_StopSound(int id)
{
	if(sound[id].dsBuffer)
	{
		sound[id].dsBuffer->Stop();
		sound[id].dsBuffer->SetCurrentPosition(0);
	}
  return true;
}
//=================================================================================================================
bool DSound::DS_StopAllSound(void)
{
	for(int i=0; i<MAX_SOUND; i++)DS_StopSound(i);
  return true;
}
//=================================================================================================================
bool DSound::DS_DeleteSound(int id)
{
	if(!DS_StopSound(id))return false;

	if(sound[id].dsBuffer)
	{
		sound[id].dsBuffer->Release();
		sound[id].dsBuffer = NULL;
	  return true;
	}
  return true;
}
//=================================================================================================================
bool DSound::DS_DeleteAllSound(void)
{
	for(int i=0; i<MAX_SOUND; i++)DS_DeleteSound(i);
  return true;
}
//=================================================================================================================