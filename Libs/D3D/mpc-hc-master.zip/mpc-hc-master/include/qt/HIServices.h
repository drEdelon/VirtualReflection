/*
     File:       HIServices.h
 
     Contains:   Master include for HIServices framework
 
     Version:    QuickTime 7.3
 
     Copyright:  (c) 2007 (c) 2002 by Apple Computer, Inc., all rights reserved.
 
     Bugs?:      For bug reports, consult the following page on
                 the World Wide Web:
 
                     http://developer.apple.com/bugreporter/
 
*/
#ifndef __HISERVICES__
#define __HISERVICES__

#error this file is for use as a framework master only

#endif /* __HISERVICES__ */

